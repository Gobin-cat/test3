package com.example.demo.entity;

import lombok.Data;

@Data
public class Filed {
    private String name;
    private String type;
    private String pack;

}
