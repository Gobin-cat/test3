package com.example.demo.util;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.demo.entity.ClassInfo;
import com.example.demo.entity.Filed;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class JsonToObjectUtil {
    //去重
    public static boolean checkRepeat(List<ClassInfo> classInfos, int hashCode) {
        for (int i = 0; i < classInfos.size(); i++){
            String oldHashCode = classInfos.get(i).getHashCode();
            if (oldHashCode.equals(String.valueOf(hashCode))){
               return false;
            }
        }
        return true;
    }
    //遍历json
    public static void  analysisJson(JSONObject jsonObject,List<ClassInfo> classInfos,String className){
        Map<String, Object> map = new HashMap<>();
        //转map
        for (Map.Entry<String, Object> entry : jsonObject.entrySet()) {
            map.put(entry.getKey(), entry.getValue());
        }
        //迭代器遍历
        Iterator<Map.Entry<String, Object>> entries = map.entrySet().iterator();
        List<Filed> fileds=new ArrayList<>();
        ClassInfo classInfo = new ClassInfo();
        while(entries.hasNext()){
            Map.Entry<String, Object> entry = entries.next();
            Filed filed = new Filed();
            String keyName = entry.getKey();
            filed.setName(keyName);
            String packageName = map.get(keyName).getClass().getTypeName();
            int i = map.get(keyName).getClass().getTypeName().split("\\.").length - 1;
            //typename
            String typeName = map.get(keyName).getClass().getTypeName().split("\\.")[i];
            filed.setType(typeName);
            filed.setPack(packageName);
            fileds.add(filed);
            Object value = entry.getValue();
            //数据类型判断
            if (value instanceof JSONObject&&((JSONObject) value).size()!=0&&!((JSONObject) value).isEmpty()&&value!=null){
                //循环
                analysisJson((JSONObject)value,classInfos,keyName);
            }else if(value instanceof JSONArray&&!((JSONArray) value).isEmpty()&&((JSONArray) value).size()!=0&&value!=null){
                Object o = ((JSONArray) value).get(0);
                analysisJson((JSONObject)o,classInfos,keyName);
            }
        }
        //生成hash值
        int hashcode = toHash(fileds);
        //去重
        if (checkRepeat(classInfos, hashcode)){
            //没有相同的进行添加
            classInfo.setFileList(fileds);
            classInfo.setHashCode(String.valueOf(hashcode));
            classInfo.setClassname("A"+String.valueOf(hashcode));
            //classInfo.setClassname(className);
            classInfos.add(classInfo);
        }
    }
    //字段生成hashCode
    public  static int toHash(List<Filed> fileds){
        if(fileds.size()==0||fileds==null||fileds.isEmpty()){
            return 0;
        }
        String filedString=null;
        for (int i=0;i<fileds.size();i++){
            filedString=filedString+fileds.get(i);
        }
        int arraySize = 11113; // 数组大小一般取质数
        int hashCode = 0;
        for (int i = 0; i < filedString.length(); i++) { // 从字符串的左边开始计算
            int letterValue = filedString.charAt(i) - 96;// 将获取到的字符串转换成数字，比如a的码值是97，则97-96=1
            // 就代表a的值，同理b=2；
            hashCode = ((hashCode << 5) + letterValue) % arraySize;// 防止编码溢出，对每步结果都进行取模运算
        }
        return hashCode;
    }
    //将对应类名转化成hashcode
    public static int classHashCode(String keyName) {
        // 数组大小一般取质数
        int arraySize = 11113;
        int hashCode = 0;
        String result = null;
        // 从字符串的左边开始计算
        for (int i = 0; i < keyName.length(); i++) {
            // 将获取到的字符串转换成数字，比如a的码值是97，则97-96=1
            int letterValue = keyName.charAt(i) - 96;
            // 就代表a的值，同理b=2；
            // 防止编码溢出，对每步结果都进行取模运算
            hashCode = ((hashCode << 5) + letterValue) % arraySize;
        }
        return hashCode;
    }
}
