package com.example.demo.service;

import com.example.demo.entity.ClassInfo;
import com.example.demo.util.WriteClass;
import org.springframework.stereotype.Service;

import java.io.IOException;
@Service
public class InterpreterImpl implements Interpreter{

    @Override
    public void writeClass(ClassInfo classInfo,String path) throws IOException {
        WriteClass.writeFile(classInfo,path);
        //生成文件
    }
}
